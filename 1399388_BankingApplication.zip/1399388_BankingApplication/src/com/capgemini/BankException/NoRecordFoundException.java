package com.capgemini.BankException;

public class NoRecordFoundException extends Exception
{
	public String toString() {
	  	  
	  	  return "There is no customer details with this transaction_id";
	    }
}
