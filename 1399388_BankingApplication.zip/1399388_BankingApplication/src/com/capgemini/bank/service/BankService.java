package com.capgemini.bank.service;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.dao.BankDAO;

public class BankService implements IBankService
{
	public int addDD_details(BankBean bank) 
	{
		BankDAO obj=new BankDAO();
		return 0;
	}
	
	public BankBean getDD_Details(int transaction_id) {
		BankDAO obj=new BankDAO();
		return null;
	}
	
}
