package com.capgemini.bank.service;

import com.capgemini.bank.bean.BankBean;

public interface IBankService
{
	int addDD_details(BankBean bank);
	BankBean getDD_Details(int transaction_id);
}
