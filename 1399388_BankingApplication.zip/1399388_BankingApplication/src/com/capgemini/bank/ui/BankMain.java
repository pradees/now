package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.dao.BankDAO;
import com.capgemini.bank.service.BankService;

public class BankMain 
{


	public static void main(String[] args) 
	{
		

		 Scanner sc = new Scanner(System.in);
		 BankBean Bank = new BankBean();
		 BankDAO obj = new BankDAO();
		 BankService bs = new BankService();
		    
		
		
			System.out.println("XYZ Bank Application");
			System.out.println("1. Enter Demand DraftDetails");
			System.out.println("2. Print Demand Draft");
			System.out.println("3. Exit");
		
			  int val=sc.nextInt();
		
		switch(val)
		{
		case 1:
			System.out.println("Enter the name of the customer:");
			String name =sc.next();
			Bank.setCustomer_name(name);
			
			System.out.println("In favor of:");
			String favor =sc.next();
			Bank.setIn_favor_of(favor);
			
			System.out.println("Enter customer phone number:");
			String number= sc.next();
			Bank.setPhone_number(number);
			
			System.out.println("Enter demand draft amount (in Rs):");
			int dd =sc.nextInt();
			Bank.setDd_amount(dd);
			
			System.out.println("Enter Remarks");
			String remark =sc.next();
			Bank.setDd_description(remark);
			
			obj.addDD_details(Bank);
			
			break;
			
			
			
		case 2:
			System.out.println("Enter the transaction_id to be searched:");
			int id=sc.nextInt();
			Bank.setTransaction_id(id);
			bs.getDD_Details(id);
			break;
			
			
			
			
		case 3:
			System.out.print("Exit Bank Application");
			System.exit(0);
			break;
			
			
			
		default:
			System.out.println("Enter a valid option[1-3]");
			
			
			
		}
		
		
		// TODO Auto-generated method stub

	}

}
