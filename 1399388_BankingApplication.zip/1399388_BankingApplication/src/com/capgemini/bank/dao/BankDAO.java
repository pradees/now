package com.capgemini.bank.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.BankException.NoRecordFoundException;
import com.capgemini.bank.bean.BankBean;

import com.capgemini.util.CommonConnection;

public class BankDAO implements IBankDAO
{

	private Connection cn;
	private PreparedStatement pst;
	private Statement st;
	private ResultSet rs;
	
	public int addDD_details(BankBean bank) 
	{
		try
		{
			 cn=CommonConnection.getcon();
			 pst=cn.prepareStatement("Insert into demand_draft1 values(transaction_id2.nextval ,? ,? ,? ,sysdate,?,? )");
			 
			 pst.setString(1,bank.getCustomer_name());
			 pst.setString(2,bank.getIn_favor_of());
			 pst.setString(3,bank.getPhone_number());
			 
			 pst.setInt(4,bank.getDd_amount());
			 pst.setString(5,bank.getDd_description());
			 
			 
			 
			 pst.executeUpdate();
			 System.out.println(" Your Demand Draft request has been succesfully registered ");	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		// TODO Auto-generated method stub
		
	}

	@Override
	public BankBean getDD_Details(int transaction_id) 
	{

		try
		{
			cn=CommonConnection.getcon();
			Statement st=cn.createStatement();			
			int i=st.executeUpdate("select * from demand_draft1 where patient_id="+transaction_id);	
			
			
	   	 if(i>0) {
	   		ResultSet rs=st.executeQuery("select * from demand_draft1 where patient_id="+transaction_id);
	   		
	   		while(rs.next())
	   	 {
	   			System.out.println(i);
	   		 System.out.println("Name of the Patient:"+rs.getString(2)+"\nAge:"+rs.getInt(3)+"\nPhone Number:"+rs.getLong(4)+"\nDescription:"+rs.getString(5)+"\nConsultation Date:"+LocalDate.now());
	   	 }
		} 
	   	 else 
	   	 {
	   		 System.out.println("result not found");
	   	 }
	   	
		} 
		catch (Exception e) 
		{			
			e.printStackTrace();
		}   	 
		return null;
		
	
		return null;
	}


	 
	}

	


