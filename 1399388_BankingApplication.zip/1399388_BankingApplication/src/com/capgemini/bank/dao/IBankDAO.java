package com.capgemini.bank.dao;

import com.capgemini.bank.bean.BankBean;

public interface IBankDAO 
{
	int addDD_details(BankBean bank);
	BankBean getDD_Details(int transaction_id);
}
