
CREATE TABLE demand_draft(transaction_id number,customer_name varchar(20),in_favor_of varchar(20),phone_number varchar(20),date_of_transaction date,dd_amount number,dd_commission number,dd_description varchar(20));

Table created.

CREATE SEQUENCE transaction_id1 start with 1001;

Sequence created.
